const button = document.querySelector("button");
button.addEventListener("click", () => {
  const num1 = document.querySelector("#num1").value;
  const num2 = document.querySelector("#num2").value;
  if (num1 === "" && num2 === "") {
    document.querySelector("#num1err").textContent = "Please enter a number";
    document.querySelector("#num2err").textContent = "Please enter a number";
    return;
  } else if (num1 === "") {
    document.querySelector("#num2err").textContent = "Please enter a number";
    return;
  } else if (num2 === "") {
    document.querySelector("#num1err").textContent = "Please enter a number";
    return;
  } else {
    document.querySelector("#num1err").textContent = "";
    document.querySelector("#num2err").textContent = "";
  }
  const sum = Number(num1) + Number(num2);
  alert(`The sum of ${num1} and ${num2} is ${sum}`);
  document.querySelector("#result").textContent = "The sum is " + sum;
});
