const country = document.getElementById("country");
const city = document.getElementById("city");
country.addEventListener("change", () => {
  city.innerHTML = "";
  if (country.value === "India") {
    const cities = ["Delhi", "Mumbai", "Kolkata", "Chennai"];
    cities.forEach((cityName) => {
      const option = document.createElement("option");
      option.value = cityName;
      option.innerText = cityName;
      city.appendChild(option);
    });
  } else if (country.value === "USA") {
    const cities = ["New York", "Washington", "Los Angeles", "Chicago"];
    cities.forEach((cityName) => {
      const option = document.createElement("option");
      option.value = cityName;
      option.innerText = cityName;
      city.appendChild(option);
    });
  } else if (country.value === "UK") {
    const cities = ["London", "Manchester", "Liverpool", "Birmingham"];
    cities.forEach((cityName) => {
      const option = document.createElement("option");
      option.value = cityName;
      option.innerText = cityName;
      city.appendChild(option);
    });
  } else {
    const option = document.createElement("option");
    option.value = "";
    option.innerText = "--- Select City ---";
    city.appendChild(option);
  }
});
